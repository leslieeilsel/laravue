/*
 Navicat Premium Data Transfer

 Source Server         : leslieeilsel
 Source Server Type    : MySQL
 Source Server Version : 50722
 Source Host           : localhost:3306
 Source Schema         : slms_vue

 Target Server Type    : MySQL
 Target Server Version : 50722
 File Encoding         : 65001

 Date: 20/02/2019 16:48:40
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for iba_system_department
-- ----------------------------
DROP TABLE IF EXISTS `iba_system_department`;
CREATE TABLE `iba_system_department`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `sort` int(11) NULL DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `parent_id` int(10) UNSIGNED NULL DEFAULT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
  `create_by` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `update_by` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of iba_system_department
-- ----------------------------
INSERT INTO `iba_system_department` VALUES (1, '体彩中心', 1, 1, 0, '体彩中心', 'Admin', 'Admin', '2019-01-09 10:18:23', '2019-01-09 18:44:07');
INSERT INTO `iba_system_department` VALUES (2, '电彩部', 1, 1, 1, '电彩部', 'Admin', NULL, '2019-01-07 14:38:42', NULL);
INSERT INTO `iba_system_department` VALUES (3, '即开部', 2, 1, 1, '即开部', 'Admin', NULL, '2019-01-07 14:39:22', NULL);
INSERT INTO `iba_system_department` VALUES (4, '技术部', 3, 1, 1, '技术部', 'Admin', NULL, '2019-01-07 14:40:24', NULL);
INSERT INTO `iba_system_department` VALUES (5, '财务部', 4, 1, 1, '财务部', 'Admin', NULL, '2019-01-07 14:40:53', NULL);

-- ----------------------------
-- Table structure for iba_system_dict
-- ----------------------------
DROP TABLE IF EXISTS `iba_system_dict`;
CREATE TABLE `iba_system_dict`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `created_user_id` int(11) NULL DEFAULT NULL,
  `updated_user_id` int(11) NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of iba_system_dict
-- ----------------------------
INSERT INTO `iba_system_dict` VALUES (1, '性别', 'sex', NULL, 1, NULL, '2019-01-25 10:22:35', '2019-01-25 10:22:35');

-- ----------------------------
-- Table structure for iba_system_dict_data
-- ----------------------------
DROP TABLE IF EXISTS `iba_system_dict_data`;
CREATE TABLE `iba_system_dict_data`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `dict_id` int(10) UNSIGNED NOT NULL,
  `description` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `created_user_id` int(11) NULL DEFAULT NULL,
  `updated_user_id` int(11) NULL DEFAULT NULL,
  `sort` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of iba_system_dict_data
-- ----------------------------
INSERT INTO `iba_system_dict_data` VALUES (1, '男', '0', 1, NULL, 1, NULL, 0, 1, '2019-01-25 10:23:00', '2019-01-25 10:23:00');
INSERT INTO `iba_system_dict_data` VALUES (2, '女', '1', 1, NULL, 1, NULL, 1, 1, '2019-01-25 10:23:23', '2019-01-25 10:23:23');

-- ----------------------------
-- Table structure for ibiart_slms_role_menus
-- ----------------------------
DROP TABLE IF EXISTS `ibiart_slms_role_menus`;
CREATE TABLE `ibiart_slms_role_menus`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_id` int(10) UNSIGNED NOT NULL,
  `menu_id` int(10) UNSIGNED NOT NULL,
  `checked` int(10) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 185 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ibiart_slms_role_menus
-- ----------------------------
INSERT INTO `ibiart_slms_role_menus` VALUES (18, 1, 1, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (19, 1, 2, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (20, 1, 8, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (21, 1, 9, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (22, 1, 10, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (23, 1, 11, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (24, 1, 12, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (25, 1, 13, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (26, 1, 14, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (27, 1, 15, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (28, 1, 16, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (29, 1, 17, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (30, 2, 1, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (31, 2, 2, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (32, 2, 3, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (33, 2, 4, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (34, 2, 5, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (35, 2, 6, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (36, 2, 7, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (37, 2, 8, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (38, 2, 9, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (39, 2, 10, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (40, 2, 11, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (41, 2, 12, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (42, 2, 13, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (43, 2, 14, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (44, 2, 15, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (45, 2, 16, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (46, 2, 17, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (47, 3, 1, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (48, 3, 2, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (49, 3, 3, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (50, 3, 4, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (51, 3, 5, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (52, 3, 6, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (53, 3, 7, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (54, 5, 1, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (55, 5, 2, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (56, 5, 3, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (57, 5, 4, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (58, 5, 5, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (59, 5, 6, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (60, 5, 7, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (61, 5, 8, 0);
INSERT INTO `ibiart_slms_role_menus` VALUES (62, 5, 13, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (63, 5, 14, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (64, 5, 15, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (65, 5, 16, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (66, 5, 17, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (163, 4, 1, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (164, 4, 2, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (165, 4, 3, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (166, 4, 4, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (167, 4, 5, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (168, 4, 6, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (169, 4, 7, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (170, 4, 8, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (171, 4, 9, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (172, 4, 10, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (173, 4, 11, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (174, 4, 12, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (175, 4, 13, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (176, 4, 14, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (177, 4, 15, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (178, 4, 16, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (179, 4, 17, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (180, 4, 21, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (181, 4, 22, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (182, 4, 23, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (183, 4, 24, 1);
INSERT INTO `ibiart_slms_role_menus` VALUES (184, 4, 25, 1);

-- ----------------------------
-- Table structure for ibiart_slms_roles
-- ----------------------------
DROP TABLE IF EXISTS `ibiart_slms_roles`;
CREATE TABLE `ibiart_slms_roles`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `is_default` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ibiart_slms_roles
-- ----------------------------
INSERT INTO `ibiart_slms_roles` VALUES (1, 'Admin', '管理员', 0, '2018-12-17 18:47:02', '2019-01-23 14:10:29');
INSERT INTO `ibiart_slms_roles` VALUES (2, 'Super_Admin', '超级管理员', 0, '2018-12-17 18:47:34', '2019-01-23 14:10:29');
INSERT INTO `ibiart_slms_roles` VALUES (3, 'Guest', '访客', 0, '2018-12-17 18:48:31', '2019-01-23 14:10:29');
INSERT INTO `ibiart_slms_roles` VALUES (4, 'User', '普通用户', 1, '2018-12-18 13:45:51', '2019-01-23 14:10:29');
INSERT INTO `ibiart_slms_roles` VALUES (5, 'Others', '其它用户', 0, '2018-12-20 11:13:59', '2019-01-23 14:10:29');

-- ----------------------------
-- Table structure for ibiart_slms_user_roles
-- ----------------------------
DROP TABLE IF EXISTS `ibiart_slms_user_roles`;
CREATE TABLE `ibiart_slms_user_roles`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for menus
-- ----------------------------
DROP TABLE IF EXISTS `menus`;
CREATE TABLE `menus`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `component` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `parent_id` int(10) UNSIGNED NULL DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `path` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `link_type` int(11) NULL DEFAULT 0,
  `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `icon` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT '',
  `target` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '_self',
  `enabled` int(11) NOT NULL DEFAULT 1,
  `sort` int(11) NULL DEFAULT NULL,
  `created_user_id` int(11) NULL DEFAULT NULL,
  `updated_user_id` int(11) NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 26 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of menus
-- ----------------------------
INSERT INTO `menus` VALUES (1, '基础', '', NULL, 0, '首页', '/', 0, NULL, 'md-home', '_self', 1, 1, 1, NULL, '2018-12-27 11:50:13', NULL);
INSERT INTO `menus` VALUES (2, '首页', 'home', 'views/sys/monitor/monitor', 1, '首页', '/home', 1, 'http://139.217.129.66:3000/public/dashboard/1eb6cf5f-c2e2-45b7-91e2-2f9b5e0f79e8', 'md-home', '_self', 1, 1, 1, 1, '2018-12-27 14:10:27', '2019-01-27 16:44:33');
INSERT INTO `menus` VALUES (3, '月报表', 'report', NULL, 0, '月报表', '/report', 0, NULL, 'ios-paper', '_self', 1, 2, 1, NULL, '2018-12-27 16:01:43', NULL);
INSERT INTO `menus` VALUES (4, '发行费分配概览表', 'fxfOverviewMonth', 'views/report/overviewMonth/fxf', 3, '发行费分配概览表', '/overviewMonth/fxf', 0, NULL, NULL, '_self', 1, 1, 1, NULL, '2018-12-27 16:03:43', NULL);
INSERT INTO `menus` VALUES (5, '公益金分配概览表', 'gyjOverviewMonth', 'views/report/overviewMonth/gyj', 3, '公益金分配概览表', '/overviewMonth/gyj', 0, NULL, NULL, '_self', 1, 2, 1, NULL, '2018-12-27 16:05:06', NULL);
INSERT INTO `menus` VALUES (6, '佣金分配概览表', 'yjOverviewMonth', 'views/report/overviewMonth/yj', 3, '佣金分配概览表', '/overviewMonth/yj', 0, NULL, NULL, '_self', 1, 3, 1, NULL, '2018-12-27 16:05:54', NULL);
INSERT INTO `menus` VALUES (7, '返奖分配概览表', 'fjOverviewMonth', 'views/report/overviewMonth/fj', 3, '返奖分配概览表', '/overviewMonth/fj', 0, NULL, NULL, '_self', 1, 4, 1, NULL, '2018-12-27 16:06:28', NULL);
INSERT INTO `menus` VALUES (8, '系统管理', 'sys-manage', NULL, 0, '系统管理', '/sys-manage', 0, NULL, 'md-briefcase', '_self', 1, 3, 1, NULL, '2019-01-03 14:36:56', NULL);
INSERT INTO `menus` VALUES (9, '用户管理', 'users', 'views/user/users', 8, '用户管理', 'users', 0, NULL, NULL, '_self', 1, 1, 1, NULL, '2019-01-25 11:08:19', NULL);
INSERT INTO `menus` VALUES (10, '角色权限管理', 'role-manage', 'views/user/role-manage', 8, '角色权限管理', 'role-manage', 0, NULL, NULL, '_self', 1, 2, 1, NULL, '2018-12-27 16:13:30', NULL);
INSERT INTO `menus` VALUES (11, '部门管理', 'department-manage', 'views/sys/department-manage/departmentManage', 8, '部门管理', 'department-manage/departmentManage', 0, NULL, NULL, '_self', 1, 3, 1, NULL, '2019-01-03 14:44:20', NULL);
INSERT INTO `menus` VALUES (12, '菜单管理', 'menuManage', 'views/sys/menu-manage/menuManage', 8, '重构菜单', 'menu-manage/menuManage', 0, NULL, NULL, '_self', 1, 4, 1, NULL, '2019-01-23 14:45:44', NULL);
INSERT INTO `menus` VALUES (13, '事件日志', 'eventlogs', 'views/sys/monitor/monitor', 8, '日志显示了程序中的潜在错误, 比如异常和调试信息。', 'eventlogs', 1, 'http://localhost:3114/logs', NULL, '_self', 1, 5, 1, 1, '2019-01-09 16:37:32', '2019-01-27 16:02:31');
INSERT INTO `menus` VALUES (14, '操作日志', 'operationlogs', 'views/sys/operationlogs', 8, '记录系统功能操作日志', 'operationlogs', 0, NULL, NULL, '_self', 1, 6, 1, NULL, '2019-01-10 02:46:52', NULL);
INSERT INTO `menus` VALUES (15, '系统设置', 'sys-setting', NULL, 0, '系统设置', '/sys-setting', 0, NULL, 'md-settings', '_self', 1, 4, 1, NULL, '2019-01-25 11:03:28', NULL);
INSERT INTO `menus` VALUES (16, '数据字典管理', 'dict', 'views/sys/dict-manage/dictManage', 15, '数据字典管理', 'dict-manage/dictManage', 0, NULL, NULL, '_self', 1, 1, 1, NULL, '2019-01-25 11:06:21', NULL);
INSERT INTO `menus` VALUES (17, '个人中心', 'profile', 'views/sys/profile/profile', 15, '个人中心', '/sys/profile', 0, NULL, NULL, '_self', 1, 2, 1, NULL, '2019-01-18 14:54:09', NULL);
INSERT INTO `menus` VALUES (21, '百度', 'baidu', 'views/sys/monitor/monitor', 15, '百度', 'baidu', 1, 'https://www.baidu.com/', '', '_self', 1, 0, 1, NULL, '2019-01-27 16:34:00', '2019-01-27 16:34:00');
INSERT INTO `menus` VALUES (22, '项目管理', 'project', NULL, 0, '项目管理', '/project', 0, NULL, 'md-medkit', '_self', 1, 0, 1, NULL, '2019-02-16 19:02:54', '2019-02-16 19:02:54');
INSERT INTO `menus` VALUES (23, '项目信息', 'projectInfo', 'views/project/project-info/projectInfo', 22, '项目信息', 'projectInfo', 0, NULL, '', '_self', 1, 0, 1, NULL, '2019-02-16 19:04:47', '2019-02-16 19:04:47');
INSERT INTO `menus` VALUES (24, '项目预览', 'projectPreview', 'views/project/project-preview/projectPreview', 22, '项目预览', 'projectPreview', 0, NULL, '', '_self', 1, 0, 1, NULL, '2019-02-16 19:13:09', '2019-02-16 19:13:09');
INSERT INTO `menus` VALUES (25, '项目预警', 'projectEarlyWarning', 'views/project/project-early-warning/projectEarlyWarning', 22, NULL, 'projectEarlyWarning', 0, NULL, '', '_self', 1, 0, 1, NULL, '2019-02-17 13:45:10', '2019-02-17 13:45:10');

-- ----------------------------
-- Table structure for operation_log
-- ----------------------------
DROP TABLE IF EXISTS `operation_log`;
CREATE TABLE `operation_log`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `method` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `path` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ip_place` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 197 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of operation_log
-- ----------------------------
INSERT INTO `operation_log` VALUES (1, '创建菜单', 'POST', 'api/menu/add', '::1', '', 0, '2019-01-18 14:12:57', NULL);
INSERT INTO `operation_log` VALUES (2, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-18 14:13:12', NULL);
INSERT INTO `operation_log` VALUES (3, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-18 14:16:42', NULL);
INSERT INTO `operation_log` VALUES (4, '设置菜单权限', 'POST', 'api/role/setrolemenus', '::1', '', 1, '2019-01-18 14:16:56', NULL);
INSERT INTO `operation_log` VALUES (5, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-18 14:18:25', NULL);
INSERT INTO `operation_log` VALUES (6, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-18 14:26:58', NULL);
INSERT INTO `operation_log` VALUES (7, '创建菜单', 'POST', 'api/menu/add', '::1', '', 1, '2019-01-18 14:54:09', NULL);
INSERT INTO `operation_log` VALUES (8, '设置菜单权限', 'POST', 'api/role/setrolemenus', '::1', '', 1, '2019-01-18 14:55:45', NULL);
INSERT INTO `operation_log` VALUES (9, '设置菜单权限', 'POST', 'api/role/setrolemenus', '::1', '', 1, '2019-01-18 14:56:23', NULL);
INSERT INTO `operation_log` VALUES (10, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-18 15:30:15', NULL);
INSERT INTO `operation_log` VALUES (11, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-18 17:15:05', NULL);
INSERT INTO `operation_log` VALUES (12, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-18 17:35:39', NULL);
INSERT INTO `operation_log` VALUES (13, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-18 17:36:01', NULL);
INSERT INTO `operation_log` VALUES (14, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-21 09:46:19', NULL);
INSERT INTO `operation_log` VALUES (15, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-21 11:25:00', NULL);
INSERT INTO `operation_log` VALUES (16, '修改密码', 'POST', 'api/user/resetPassword', '::1', '', 1, '2019-01-21 11:26:32', NULL);
INSERT INTO `operation_log` VALUES (17, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-21 11:26:57', NULL);
INSERT INTO `operation_log` VALUES (18, '修改密码', 'POST', 'api/user/resetPassword', '::1', '', 1, '2019-01-21 11:32:54', NULL);
INSERT INTO `operation_log` VALUES (19, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-21 11:34:44', NULL);
INSERT INTO `operation_log` VALUES (20, '修改密码', 'POST', 'api/user/resetPassword', '::1', '', 1, '2019-01-21 11:40:41', NULL);
INSERT INTO `operation_log` VALUES (21, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-21 11:40:54', NULL);
INSERT INTO `operation_log` VALUES (22, '修改密码', 'POST', 'api/user/resetPassword', '::1', '', 1, '2019-01-21 11:41:09', NULL);
INSERT INTO `operation_log` VALUES (23, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-21 11:41:13', NULL);
INSERT INTO `operation_log` VALUES (24, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-21 13:53:17', NULL);
INSERT INTO `operation_log` VALUES (25, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-21 16:24:37', NULL);
INSERT INTO `operation_log` VALUES (26, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-22 10:36:58', NULL);
INSERT INTO `operation_log` VALUES (27, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-22 14:17:05', NULL);
INSERT INTO `operation_log` VALUES (28, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-22 15:45:18', NULL);
INSERT INTO `operation_log` VALUES (29, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-22 17:43:18', NULL);
INSERT INTO `operation_log` VALUES (30, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-22 18:47:04', NULL);
INSERT INTO `operation_log` VALUES (31, '设置菜单权限', 'POST', 'api/role/setrolemenus', '::1', '', 1, '2019-01-22 18:53:26', NULL);
INSERT INTO `operation_log` VALUES (32, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-22 21:35:18', NULL);
INSERT INTO `operation_log` VALUES (33, '创建用户', 'POST', 'api/user/regist', '::1', '', 1, '2019-01-22 21:46:38', NULL);
INSERT INTO `operation_log` VALUES (34, '创建用户', 'POST', 'api/user/regist', '::1', '', 1, '2019-01-22 21:51:54', NULL);
INSERT INTO `operation_log` VALUES (35, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-23 09:52:39', NULL);
INSERT INTO `operation_log` VALUES (36, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-23 10:00:15', NULL);
INSERT INTO `operation_log` VALUES (37, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-23 11:04:50', NULL);
INSERT INTO `operation_log` VALUES (38, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-23 14:09:52', NULL);
INSERT INTO `operation_log` VALUES (39, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-23 14:17:36', NULL);
INSERT INTO `operation_log` VALUES (40, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-23 14:18:08', NULL);
INSERT INTO `operation_log` VALUES (41, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-23 14:20:11', NULL);
INSERT INTO `operation_log` VALUES (42, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-23 14:20:45', NULL);
INSERT INTO `operation_log` VALUES (43, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-23 14:22:40', NULL);
INSERT INTO `operation_log` VALUES (44, '创建菜单', 'POST', 'api/menu/add', '::1', '', 1, '2019-01-23 14:45:44', NULL);
INSERT INTO `operation_log` VALUES (45, '设置菜单权限', 'POST', 'api/role/setrolemenus', '::1', '', 1, '2019-01-23 14:46:08', NULL);
INSERT INTO `operation_log` VALUES (46, '设置菜单权限', 'POST', 'api/role/setrolemenus', '::1', '', 1, '2019-01-23 14:46:15', NULL);
INSERT INTO `operation_log` VALUES (47, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-23 15:24:04', NULL);
INSERT INTO `operation_log` VALUES (48, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-23 16:24:36', NULL);
INSERT INTO `operation_log` VALUES (49, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-23 16:49:09', NULL);
INSERT INTO `operation_log` VALUES (50, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-23 17:57:22', NULL);
INSERT INTO `operation_log` VALUES (51, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-23 18:00:03', NULL);
INSERT INTO `operation_log` VALUES (52, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-23 18:02:09', NULL);
INSERT INTO `operation_log` VALUES (53, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-24 09:17:54', NULL);
INSERT INTO `operation_log` VALUES (54, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-24 09:30:02', NULL);
INSERT INTO `operation_log` VALUES (55, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-24 09:34:51', NULL);
INSERT INTO `operation_log` VALUES (56, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-24 10:35:03', NULL);
INSERT INTO `operation_log` VALUES (57, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-24 11:38:33', NULL);
INSERT INTO `operation_log` VALUES (58, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-24 14:40:07', NULL);
INSERT INTO `operation_log` VALUES (59, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-24 15:42:30', NULL);
INSERT INTO `operation_log` VALUES (60, '创建菜单', 'POST', 'api/menu/addMenu', '::1', '', 1, '2019-01-24 15:47:39', NULL);
INSERT INTO `operation_log` VALUES (61, '设置菜单权限', 'POST', 'api/role/setrolemenus', '::1', '', 1, '2019-01-24 15:48:08', NULL);
INSERT INTO `operation_log` VALUES (62, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-24 15:48:21', NULL);
INSERT INTO `operation_log` VALUES (63, '创建菜单', 'POST', 'api/menu/addMenu', '::1', '', 1, '2019-01-24 15:57:29', NULL);
INSERT INTO `operation_log` VALUES (64, '创建菜单', 'POST', 'api/menu/addMenu', '::1', '', 1, '2019-01-24 15:58:21', NULL);
INSERT INTO `operation_log` VALUES (65, '创建菜单', 'POST', 'api/menu/addMenu', '::1', '', 1, '2019-01-24 16:26:03', NULL);
INSERT INTO `operation_log` VALUES (66, '创建菜单', 'POST', 'api/menu/addMenu', '::1', '', 1, '2019-01-24 16:30:31', NULL);
INSERT INTO `operation_log` VALUES (67, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-24 16:48:37', NULL);
INSERT INTO `operation_log` VALUES (68, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-24 18:53:54', NULL);
INSERT INTO `operation_log` VALUES (69, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-25 09:34:29', NULL);
INSERT INTO `operation_log` VALUES (70, '修改菜单', 'POST', 'api/menu/editMenu', '::1', '', 0, '2019-01-25 11:01:50', NULL);
INSERT INTO `operation_log` VALUES (71, '创建菜单', 'POST', 'api/menu/addMenu', '::1', '', 0, '2019-01-25 11:03:28', NULL);
INSERT INTO `operation_log` VALUES (72, '创建菜单', 'POST', 'api/menu/addMenu', '::1', '', 0, '2019-01-25 11:05:29', NULL);
INSERT INTO `operation_log` VALUES (73, '创建菜单', 'POST', 'api/menu/addMenu', '::1', '', 0, '2019-01-25 11:06:22', NULL);
INSERT INTO `operation_log` VALUES (74, '创建菜单', 'POST', 'api/menu/addMenu', '::1', '', 0, '2019-01-25 11:08:19', NULL);
INSERT INTO `operation_log` VALUES (75, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-25 11:09:56', NULL);
INSERT INTO `operation_log` VALUES (76, '设置菜单权限', 'POST', 'api/role/setrolemenus', '::1', '', 1, '2019-01-25 11:29:54', NULL);
INSERT INTO `operation_log` VALUES (77, '设置菜单权限', 'POST', 'api/role/setrolemenus', '::1', '', 1, '2019-01-25 11:32:31', NULL);
INSERT INTO `operation_log` VALUES (78, '设置菜单权限', 'POST', 'api/role/setrolemenus', '::1', '', 1, '2019-01-25 11:53:42', NULL);
INSERT INTO `operation_log` VALUES (79, '设置菜单权限', 'POST', 'api/role/setrolemenus', '::1', '', 1, '2019-01-25 11:54:16', NULL);
INSERT INTO `operation_log` VALUES (80, '设置菜单权限', 'POST', 'api/role/setrolemenus', '::1', '', 1, '2019-01-25 11:54:25', NULL);
INSERT INTO `operation_log` VALUES (81, '设置菜单权限', 'POST', 'api/role/setrolemenus', '::1', '', 1, '2019-01-25 11:54:38', NULL);
INSERT INTO `operation_log` VALUES (82, '设置菜单权限', 'POST', 'api/role/setrolemenus', '::1', '', 1, '2019-01-25 11:55:10', NULL);
INSERT INTO `operation_log` VALUES (83, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-25 11:56:41', NULL);
INSERT INTO `operation_log` VALUES (84, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-25 15:06:57', NULL);
INSERT INTO `operation_log` VALUES (85, '修改菜单', 'POST', 'api/menu/editMenu', '::1', '', 1, '2019-01-25 15:52:03', NULL);
INSERT INTO `operation_log` VALUES (86, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-25 16:38:39', NULL);
INSERT INTO `operation_log` VALUES (87, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-26 10:12:53', NULL);
INSERT INTO `operation_log` VALUES (88, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-26 10:37:47', NULL);
INSERT INTO `operation_log` VALUES (89, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-26 10:38:29', NULL);
INSERT INTO `operation_log` VALUES (90, '用户登录', 'POST', 'api/login', '::1', '', 2, '2019-01-26 10:38:52', NULL);
INSERT INTO `operation_log` VALUES (91, '用户登录', 'POST', 'api/login', '::1', '', 2, '2019-01-26 10:49:38', NULL);
INSERT INTO `operation_log` VALUES (92, '用户登录', 'POST', 'api/login', '::1', '', 2, '2019-01-26 11:05:49', NULL);
INSERT INTO `operation_log` VALUES (93, '用户登录', 'POST', 'api/login', '::1', '', 2, '2019-01-26 11:06:51', NULL);
INSERT INTO `operation_log` VALUES (94, '用户登录', 'POST', 'api/login', '::1', '', 2, '2019-01-26 11:08:42', NULL);
INSERT INTO `operation_log` VALUES (95, '用户登录', 'POST', 'api/login', '::1', '', 2, '2019-01-26 11:09:32', NULL);
INSERT INTO `operation_log` VALUES (96, '用户登录', 'POST', 'api/login', '::1', '', 2, '2019-01-26 11:10:14', NULL);
INSERT INTO `operation_log` VALUES (97, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-26 11:10:28', NULL);
INSERT INTO `operation_log` VALUES (98, '用户登录', 'POST', 'api/login', '::1', '', 2, '2019-01-26 11:11:19', NULL);
INSERT INTO `operation_log` VALUES (99, '用户登录', 'POST', 'api/login', '::1', '', 2, '2019-01-26 11:15:52', NULL);
INSERT INTO `operation_log` VALUES (100, '用户登录', 'POST', 'api/login', '::1', '', 2, '2019-01-26 11:23:56', NULL);
INSERT INTO `operation_log` VALUES (101, '用户登录', 'POST', 'api/login', '::1', '', 2, '2019-01-26 11:28:41', NULL);
INSERT INTO `operation_log` VALUES (102, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-26 11:29:00', NULL);
INSERT INTO `operation_log` VALUES (103, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-26 11:30:05', NULL);
INSERT INTO `operation_log` VALUES (104, '用户登录', 'POST', 'api/login', '::1', '', 2, '2019-01-26 11:30:18', NULL);
INSERT INTO `operation_log` VALUES (105, '用户登录', 'POST', 'api/login', '::1', '', 2, '2019-01-26 11:47:04', NULL);
INSERT INTO `operation_log` VALUES (106, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-26 12:58:32', NULL);
INSERT INTO `operation_log` VALUES (107, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-26 14:41:12', NULL);
INSERT INTO `operation_log` VALUES (108, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-26 16:31:24', NULL);
INSERT INTO `operation_log` VALUES (109, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-26 17:33:26', NULL);
INSERT INTO `operation_log` VALUES (110, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-27 14:23:18', NULL);
INSERT INTO `operation_log` VALUES (111, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-27 14:26:50', NULL);
INSERT INTO `operation_log` VALUES (112, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-27 14:37:28', NULL);
INSERT INTO `operation_log` VALUES (113, '修改菜单', 'POST', 'api/menu/editMenu', '::1', '', 1, '2019-01-27 15:24:30', NULL);
INSERT INTO `operation_log` VALUES (114, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-27 15:26:44', NULL);
INSERT INTO `operation_log` VALUES (115, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-27 15:49:44', NULL);
INSERT INTO `operation_log` VALUES (116, '修改菜单', 'POST', 'api/menu/editMenu', '::1', '', 1, '2019-01-27 15:58:30', NULL);
INSERT INTO `operation_log` VALUES (117, '修改菜单', 'POST', 'api/menu/editMenu', '::1', '', 1, '2019-01-27 16:02:31', NULL);
INSERT INTO `operation_log` VALUES (118, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-27 16:15:36', NULL);
INSERT INTO `operation_log` VALUES (119, '创建菜单', 'POST', 'api/menu/addMenu', '::1', '', 1, '2019-01-27 16:23:38', NULL);
INSERT INTO `operation_log` VALUES (120, '设置菜单权限', 'POST', 'api/role/setrolemenus', '::1', '', 1, '2019-01-27 16:23:55', NULL);
INSERT INTO `operation_log` VALUES (121, '创建菜单', 'POST', 'api/menu/addMenu', '::1', '', 1, '2019-01-27 16:29:38', NULL);
INSERT INTO `operation_log` VALUES (122, '设置菜单权限', 'POST', 'api/role/setrolemenus', '::1', '', 1, '2019-01-27 16:29:56', NULL);
INSERT INTO `operation_log` VALUES (123, '创建菜单', 'POST', 'api/menu/addMenu', '::1', '', 1, '2019-01-27 16:31:47', NULL);
INSERT INTO `operation_log` VALUES (124, '设置菜单权限', 'POST', 'api/role/setrolemenus', '::1', '', 1, '2019-01-27 16:32:05', NULL);
INSERT INTO `operation_log` VALUES (125, '创建菜单', 'POST', 'api/menu/addMenu', '::1', '', 1, '2019-01-27 16:34:00', NULL);
INSERT INTO `operation_log` VALUES (126, '设置菜单权限', 'POST', 'api/role/setrolemenus', '::1', '', 1, '2019-01-27 16:34:13', NULL);
INSERT INTO `operation_log` VALUES (127, '修改菜单', 'POST', 'api/menu/editMenu', '::1', '', 1, '2019-01-27 16:44:33', NULL);
INSERT INTO `operation_log` VALUES (128, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-27 16:46:24', NULL);
INSERT INTO `operation_log` VALUES (129, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-01-27 17:15:27', NULL);
INSERT INTO `operation_log` VALUES (130, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-02-13 09:30:28', NULL);
INSERT INTO `operation_log` VALUES (131, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-02-13 15:56:55', NULL);
INSERT INTO `operation_log` VALUES (132, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-02-15 16:22:23', NULL);
INSERT INTO `operation_log` VALUES (133, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-02-16 18:55:26', NULL);
INSERT INTO `operation_log` VALUES (134, '创建菜单', 'POST', 'api/menu/addMenu', '::1', '', 1, '2019-02-16 19:02:54', NULL);
INSERT INTO `operation_log` VALUES (135, '创建菜单', 'POST', 'api/menu/addMenu', '::1', '', 1, '2019-02-16 19:04:47', NULL);
INSERT INTO `operation_log` VALUES (136, '创建菜单', 'POST', 'api/menu/addMenu', '::1', '', 1, '2019-02-16 19:13:09', NULL);
INSERT INTO `operation_log` VALUES (137, '设置菜单权限', 'POST', 'api/role/setrolemenus', '::1', '', 1, '2019-02-16 19:14:22', NULL);
INSERT INTO `operation_log` VALUES (138, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-02-16 19:14:35', NULL);
INSERT INTO `operation_log` VALUES (139, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-02-16 19:21:22', NULL);
INSERT INTO `operation_log` VALUES (140, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-02-16 19:29:10', NULL);
INSERT INTO `operation_log` VALUES (141, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-02-16 19:45:34', NULL);
INSERT INTO `operation_log` VALUES (142, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-02-16 20:51:43', NULL);
INSERT INTO `operation_log` VALUES (143, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-02-16 22:13:34', NULL);
INSERT INTO `operation_log` VALUES (144, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-02-16 23:19:59', NULL);
INSERT INTO `operation_log` VALUES (145, '创建项目信息', 'POST', 'api/project/addDepartment', '::1', '', 1, '2019-02-17 00:10:25', NULL);
INSERT INTO `operation_log` VALUES (146, '创建项目信息', 'POST', 'api/project/addDepartment', '::1', '', 1, '2019-02-17 00:12:11', NULL);
INSERT INTO `operation_log` VALUES (147, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-02-17 00:20:14', NULL);
INSERT INTO `operation_log` VALUES (148, '创建项目信息', 'POST', 'api/project/addDepartment', '::1', '', 1, '2019-02-17 01:04:07', NULL);
INSERT INTO `operation_log` VALUES (149, '修改项目信息', 'POST', 'api/project/editDepartment', '::1', '', 1, '2019-02-17 01:21:29', NULL);
INSERT INTO `operation_log` VALUES (150, '修改项目信息', 'POST', 'api/project/editDepartment', '::1', '', 0, '2019-02-17 01:21:43', NULL);
INSERT INTO `operation_log` VALUES (151, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-02-17 01:22:15', NULL);
INSERT INTO `operation_log` VALUES (152, '修改项目信息', 'POST', 'api/project/editDepartment', '::1', '', 1, '2019-02-17 01:22:29', NULL);
INSERT INTO `operation_log` VALUES (153, '修改项目信息', 'POST', 'api/project/editDepartment', '::1', '', 1, '2019-02-17 01:22:38', NULL);
INSERT INTO `operation_log` VALUES (154, '修改项目信息', 'POST', 'api/project/editDepartment', '::1', '', 1, '2019-02-17 01:22:47', NULL);
INSERT INTO `operation_log` VALUES (155, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-02-17 02:14:03', NULL);
INSERT INTO `operation_log` VALUES (156, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-02-17 08:34:00', NULL);
INSERT INTO `operation_log` VALUES (157, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-02-17 09:57:12', NULL);
INSERT INTO `operation_log` VALUES (158, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-02-17 11:12:32', NULL);
INSERT INTO `operation_log` VALUES (159, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-02-17 12:13:05', NULL);
INSERT INTO `operation_log` VALUES (160, '创建项目信息', 'POST', 'api/project/addDepartment', '::1', '', 1, '2019-02-17 13:10:21', NULL);
INSERT INTO `operation_log` VALUES (161, '创建项目信息', 'POST', 'api/project/addDepartment', '::1', '', 1, '2019-02-17 13:10:55', NULL);
INSERT INTO `operation_log` VALUES (162, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-02-17 13:23:01', NULL);
INSERT INTO `operation_log` VALUES (163, '创建项目信息', 'POST', 'api/project/addDepartment', '::1', '', 1, '2019-02-17 13:24:18', NULL);
INSERT INTO `operation_log` VALUES (164, '创建菜单', 'POST', 'api/menu/addMenu', '::1', '', 1, '2019-02-17 13:45:10', NULL);
INSERT INTO `operation_log` VALUES (165, '设置菜单权限', 'POST', 'api/role/setrolemenus', '::1', '', 1, '2019-02-17 13:45:22', NULL);
INSERT INTO `operation_log` VALUES (166, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-02-17 14:36:19', NULL);
INSERT INTO `operation_log` VALUES (167, '创建项目信息', 'POST', 'api/project/addDepartment', '::1', '', 1, '2019-02-17 14:42:07', NULL);
INSERT INTO `operation_log` VALUES (168, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-02-17 15:38:30', NULL);
INSERT INTO `operation_log` VALUES (169, '修改项目信息', 'POST', 'api/project/editDepartment', '::1', '', 1, '2019-02-17 16:04:56', NULL);
INSERT INTO `operation_log` VALUES (170, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-02-17 20:54:55', NULL);
INSERT INTO `operation_log` VALUES (171, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-02-17 22:13:14', NULL);
INSERT INTO `operation_log` VALUES (172, '修改项目信息', 'POST', 'api/project/editDepartment', '::1', '', 1, '2019-02-17 22:50:18', NULL);
INSERT INTO `operation_log` VALUES (173, '修改项目信息', 'POST', 'api/project/editDepartment', '::1', '', 1, '2019-02-17 22:50:29', NULL);
INSERT INTO `operation_log` VALUES (174, '修改项目信息', 'POST', 'api/project/editDepartment', '::1', '', 1, '2019-02-17 22:50:36', NULL);
INSERT INTO `operation_log` VALUES (175, '修改项目信息', 'POST', 'api/project/editDepartment', '::1', '', 1, '2019-02-17 22:50:43', NULL);
INSERT INTO `operation_log` VALUES (176, '修改项目信息', 'POST', 'api/project/editDepartment', '::1', '', 1, '2019-02-17 22:52:55', NULL);
INSERT INTO `operation_log` VALUES (177, '修改项目信息', 'POST', 'api/project/editDepartment', '::1', '', 1, '2019-02-17 22:53:51', NULL);
INSERT INTO `operation_log` VALUES (178, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-02-17 23:23:14', NULL);
INSERT INTO `operation_log` VALUES (179, '修改项目信息', 'POST', 'api/project/editDepartment', '::1', '', 1, '2019-02-17 23:34:57', NULL);
INSERT INTO `operation_log` VALUES (180, '修改项目信息', 'POST', 'api/project/editDepartment', '::1', '', 1, '2019-02-17 23:35:03', NULL);
INSERT INTO `operation_log` VALUES (181, '修改项目信息', 'POST', 'api/project/editDepartment', '::1', '', 1, '2019-02-17 23:35:08', NULL);
INSERT INTO `operation_log` VALUES (182, '修改项目信息', 'POST', 'api/project/editDepartment', '::1', '', 1, '2019-02-17 23:35:13', NULL);
INSERT INTO `operation_log` VALUES (183, '修改项目信息', 'POST', 'api/project/editDepartment', '::1', '', 1, '2019-02-17 23:35:19', NULL);
INSERT INTO `operation_log` VALUES (184, '修改项目信息', 'POST', 'api/project/editDepartment', '::1', '', 1, '2019-02-17 23:35:24', NULL);
INSERT INTO `operation_log` VALUES (185, '修改项目信息', 'POST', 'api/project/editDepartment', '::1', '', 1, '2019-02-17 23:51:43', NULL);
INSERT INTO `operation_log` VALUES (186, '修改项目信息', 'POST', 'api/project/editDepartment', '::1', '', 1, '2019-02-17 23:57:01', NULL);
INSERT INTO `operation_log` VALUES (187, '修改项目信息', 'POST', 'api/project/editDepartment', '::1', '', 1, '2019-02-18 00:04:07', NULL);
INSERT INTO `operation_log` VALUES (188, '修改项目信息', 'POST', 'api/project/editDepartment', '::1', '', 1, '2019-02-18 00:04:15', NULL);
INSERT INTO `operation_log` VALUES (189, '修改项目信息', 'POST', 'api/project/editDepartment', '::1', '', 1, '2019-02-18 00:04:20', NULL);
INSERT INTO `operation_log` VALUES (190, '修改项目信息', 'POST', 'api/project/editDepartment', '::1', '', 1, '2019-02-18 00:04:25', NULL);
INSERT INTO `operation_log` VALUES (191, '修改项目信息', 'POST', 'api/project/editDepartment', '::1', '', 1, '2019-02-18 00:04:30', NULL);
INSERT INTO `operation_log` VALUES (192, '修改项目信息', 'POST', 'api/project/editDepartment', '::1', '', 1, '2019-02-18 00:04:34', NULL);
INSERT INTO `operation_log` VALUES (193, '修改项目信息', 'POST', 'api/project/editDepartment', '::1', '', 1, '2019-02-18 00:04:38', NULL);
INSERT INTO `operation_log` VALUES (194, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-02-18 18:17:00', NULL);
INSERT INTO `operation_log` VALUES (195, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-02-20 15:03:34', NULL);
INSERT INTO `operation_log` VALUES (196, '用户登录', 'POST', 'api/login', '::1', '', 1, '2019-02-20 16:18:40', NULL);

-- ----------------------------
-- Table structure for password_resets
-- ----------------------------
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets`  (
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  INDEX `password_resets_email_index`(`email`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of password_resets
-- ----------------------------
INSERT INTO `password_resets` VALUES ('admin@admin.com', '$2y$10$099y9HWV.8dLZvmyq81bXOelt6gMnokHjPLWsGtYFWgEnsbZCdNVC', '2018-11-29 18:02:23');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `avatar` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `desc` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `department_id` int(11) NULL DEFAULT NULL,
  `group_id` int(11) NULL DEFAULT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `last_login` timestamp(0) NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (1, 'admin', 'Admin', '15594990729', 'admin@admin.com', NULL, '$2y$10$q7IuhSqsnGL5g3CNQEypleEuDMZrJyQImZqwSlLEORMoGHBp9u9.u', '超级管理员', 1, 4, NULL, '2019-02-20 16:18:40', '2018-11-25 00:06:23', '2019-02-20 16:18:40');
INSERT INTO `users` VALUES (2, 'user01', 'user01', '12345678900', 'user01@admin.com', NULL, '$2y$10$rtuz3jfr81IKP8Mmm/pLBOvYq270GD2ReG9FOJPzcL14DySDD7SrS', 'user01', 2, 5, NULL, '2019-01-26 11:47:04', '2019-01-09 15:11:02', '2019-01-26 11:47:04');
INSERT INTO `users` VALUES (3, 'user02', 'user02', '12345678900', 'user02@user02.com', NULL, '$2y$10$5uRNH/DJLS9.gOYwpTp1ROmgcwl8HejJrdhhBQka/WyHxmE28jC6S', 'user02', 3, 5, NULL, NULL, '2019-01-10 02:44:13', NULL);
INSERT INTO `users` VALUES (4, 'user03', 'user03', '12345678901', 'user03@user03.com', NULL, '$2y$10$9MoQkbhMrQfjKYhVm5ltSekQqHwb/2kuthB3tPPYvAHpymFhrgQ7u', 'user03', 3, NULL, NULL, NULL, '2019-01-22 21:46:38', NULL);
INSERT INTO `users` VALUES (5, 'user04', 'user04', '12345678901', 'user04@user04.com', NULL, '$2y$10$Tem47zuM67AXxn8Aq/WUmuiE8p5/TGdXbMz2iCPT/JECRI/OURCmO', 'user04', 4, 3, NULL, NULL, '2019-01-22 21:51:53', NULL);

SET FOREIGN_KEY_CHECKS = 1;
